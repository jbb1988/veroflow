import SwiftUI
import Foundation

// MARK: - Types

enum VolumeUnit: String, CaseIterable, Codable, Identifiable {
    case gallons = "Gallons"
    case liters = "Liters"
    case cubicFeet = "Cubic Feet"
    
    var id: Self { self }
}

enum TestType: String, CaseIterable, Codable {
    case lowFlow = "Low Flow"
    case highFlow = "High Flow"
}

struct MeterReading: Codable {
    var smallMeterStart: Double
    var smallMeterEnd: Double
    var largeMeterStart: Double
    var largeMeterEnd: Double
    var totalVolume: Double
    var flowRate: Double
    
    var accuracy: Double {
        let smallMeterDiff = smallMeterEnd - smallMeterStart
        let largeMeterDiff = largeMeterEnd - largeMeterStart
        let totalMeterVolume = smallMeterDiff + largeMeterDiff
        return (totalMeterVolume / totalVolume) * 100
    }
    
    init(smallMeterStart: Double, smallMeterEnd: Double, largeMeterStart: Double, largeMeterEnd: Double, totalVolume: Double, flowRate: Double) {
        self.smallMeterStart = smallMeterStart
        self.smallMeterEnd = smallMeterEnd
        self.largeMeterStart = largeMeterStart
        self.largeMeterEnd = largeMeterEnd
        self.totalVolume = totalVolume
        self.flowRate = flowRate
    }
}

struct TestResult: Identifiable, Codable {
    let id: UUID
    let testType: TestType
    let reading: MeterReading
    var notes: String
    let date: Date
    var meterImageData: Data?
    
    var isPassing: Bool {
        switch testType {
        case .lowFlow:
            return reading.accuracy >= 95 && reading.accuracy <= 101
        case .highFlow:
            return reading.accuracy >= 98.5 && reading.accuracy <= 101.5
        }
    }
    
    init(id: UUID = UUID(), testType: TestType, reading: MeterReading, notes: String = "", date: Date = Date(), meterImageData: Data? = nil) {
        self.id = id
        self.testType = testType
        self.reading = reading
        self.notes = notes
        self.date = date
        self.meterImageData = meterImageData
    }
}

struct Configuration: Codable {
    var preferredVolumeUnit: VolumeUnit = .gallons
}
